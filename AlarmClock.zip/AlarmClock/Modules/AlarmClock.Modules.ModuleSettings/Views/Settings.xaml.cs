﻿using System.Windows.Controls;

namespace AlarmClock.Modules.ModuleSettings.Views
{
    /// <summary>
    /// Interaction logic for Settings
    /// </summary>
    public partial class Settings : UserControl
    {
        public Settings()
        {
            InitializeComponent();
        }
    }
}
