﻿using System.Windows.Controls;

namespace AlarmClock.Modules.ViewModules.Views
{
    /// <summary>
    /// Interaction logic for MainViewWindow
    /// </summary>
    public partial class MainViewWindow : UserControl
    {
        public MainViewWindow()
        {
            InitializeComponent();
        }
    }
}
