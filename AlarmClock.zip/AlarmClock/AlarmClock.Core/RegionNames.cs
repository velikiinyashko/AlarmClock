﻿
namespace AlarmClock.Core
{
    public static class RegionNames
    {
        public const string ContentRegion = "ContentRegion";
        public const string AlarmsRegion = "AlarmsRegion";
    }
}
