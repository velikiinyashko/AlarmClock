﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlarmClock.Core.Interfaces
{    public interface INotifyIcon
    {
        void Message(string Message);
    }
}
